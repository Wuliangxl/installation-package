#!/bin/bash

#awk -F ":" '{print $3}' $(curl -s https://v1.hitokoto.cn/?c=a)

echo "1" $a

printf "$a"


