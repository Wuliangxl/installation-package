#!/bin/sh
#基于Xtrabackup的MySQL数据库备份脚本，每周日全量备份，其他增量备份

#MySQL配置文件
mysqlConfig="/etc/my.cnf"
#MySQL的sock文件
mysqlSocket="/tmp/mysql.sock"
#数据库用户
dbUser="root"
#数据库密码
dbPassword="123456"

#全量备份主目录
fullBackupPath="/bak/mysql/ceshi/full"
#增量备份主目录
incrBackupPath="/bak/mysql/ceshi/incr"
#备份日志主目录及
logPath="/bak/mysql/ceshi/logs"
#备份日志文件名
logfile="/bak/mysql/ceshi/logs/backup_$(date +%Y%m%d).log"

#数据库备份保存天数
SAVE_DAYS=7

#清理备份保存天数之前的数据文件
find $fullBackupPath -type d -mtime +$SAVE_DAYS |xargs rm -rf
find $incrBackupPath -type d -mtime +$SAVE_DAYS |xargs rm -rf

#格式化今天的日期(年月日)
todayFormat=$(date -d "today" +%Y%m%d)
#格式化昨天的日期(年月日)
yesterdayformat=$(date -d "yesterday" +%Y%m%d)
#格式化昨天的星期标识(0~6表示周日~周六)
todayWeekFlg=`date -d ${todayFormat} +%w`
#格式化昨天的日期标识(0~6表示周日~周六)
yesterdayWeekFlg=`date -d ${yesterdayformat} +%w`

#一、第一次备份
if [ ! -d $fullBackupPath/$todayFormat ] && [ ! -d $fullBackupPath/$yesterdayformat ] && [ ! -d $incrBackupPath/$todayFormat ] && [ ! -d $incrBackupPath/$yesterdayformat ];then
  #全量备份
  xtrabackup --defaults-file=$mysqlConfig --backup --user=$dbUser --password=$dbPassword --socket=$mysqlSocket --compress --target-dir=$fullBackupPath/$todayFormat 2>> ${logfile}
#二、不是第一次备份
else
  #2.1 今天是周日
  if [ $todayWeekFlg == "0" ];then
    #全量备份
    xtrabackup --defaults-file=$mysqlConfig --backup --user=$dbUser --password=$dbPassword --socket=$mysqlSocket --compress --target-dir=$fullBackupPath/$todayFormat 2>> ${logfile}
  #2.2 今天不是周日
  else
    #2.2.1 昨天是周日或昨天有全量备份
    if [ $yesterdayWeekFlg == "0" ] || [ -d $fullBackupPath/$yesterdayformat ];then
      #增量备份: 依赖于昨天的全量备份  
      xtrabackup --defaults-file=$mysqlConfig --backup --user=$dbUser --password=$dbPassword --socket=$mysqlSocket --compress --target-dir=$incrBackupPath/$todayFormat --incremental-basedir=$fullBackupPath/$yesterdayformat 2>> ${logfile}
    #2.2.1 昨天不是周日并且昨天也没有全量备份
    else
      #增量备份: 依赖于昨天的增量备份
      xtrabackup --defaults-file=$mysqlConfig --backup --user=$dbUser --password=$dbPassword --socket=$mysqlSocket --compress --target-dir=$incrBackupPath/$todayFormat --incremental-basedir=$incrBackupPath/$yesterdayformat 2>> ${logfile}
    fi
  fi
fi
exit 0

