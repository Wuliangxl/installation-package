#!/bin/bash
i=0
#code=$( echo $(curl -I -m 10 -o /dev/null -s -w %{http_code} https://wttr.in/Nan+Chang))
code=$( echo $(curl -I -m 10 -o /dev/null -s -w %{http_code} https://www.baidu.com))
str=""
arry=("\\" "|" "/" "-")


while [ $i -le 100 ]
    do
  		let index=i%4
 	if  [ $i -le 20 ] 
    	then
    		let color=44
    		let bg=34
  	elif [ $i -le 45 ]
    	then
    		let color=43
     		let bg=33
  	elif [ $i -le 75 ]
     	then
     		let color=41
     		let bg=31
  	else
     		let color=42
     		let bg=32

  	fi    
  	printf "\033[${color};${bg}m%-s\033[0m %d %c\r" "$str" "$i" "${arry[$index]}"
  	usleep 50000
  	let i=i+1
        str+="#"
	if [ $code -eq 200 ];then
	echo "加载成功!"
	exit

fi
    done

printf "\n"


