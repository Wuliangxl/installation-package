#!/bin/bash
i=0
str=""
arry=("\\" "|" "/" "-")
while [ $i -le 100 ]
do
  let index=i%4
  printf "[%-100s] %d %c\r" "$str" "$i" "${arry[$index]}"
  sleep 0.1
  let i=i+1
  str+="#"
done
printf "\n"

