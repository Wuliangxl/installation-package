#!/bin/sh
#基于Xtrabackup的MySQL数据库恢复脚本,手动执行恢复

#全量备份主目录
fullBackupPath="/bak/mysql/ceshi/full"
#增量备份主目录
incrBackupPath="/bak/mysql/ceshi/incr"
#全量备份日期(最新)
fullBackupDate="20210904"
#增量备份日期(最新)
incrBackupDate="20210827"
#MySQL配置文件
mysqlConfig="/etc/my.cnf"

#数据恢复日志文件
logfile="/bak/mysql/ceshi/logs/recovery_$(date +%Y%m%d).log"

#格式化全量备份日期为秒数
fullBackupTime=`date -d "$fullBackupDate" +%s`
#格式化增量备份日期为秒数
incrBackupTime=`date -d "$incrBackupDate" +%s`
#计算两个日期之间的天数差
diffTimes=$[$incrBackupTime - $fullBackupTime]
#天数差
diffDays=$[diffTimes/86400]

#解压全量备份的压缩文件
for j in $(find $fullBackupPath/$fullBackupDate -name "*.qp"); do qpress -d $j $(dirname $j) && rm -rf $j; done;

#按天数差遍历：从最新全量备份依次预恢复到最新增量备份
for((i=0;i<=diffDays;i++))
do
  #预恢复备份日期
  prepareRevoveryDate=`date -d "$fullBackupDate $i day" +%Y%m%d`
  #一、天数差为0
  if [ $diffDays == 0 ];then
    #预恢复最新全量备份,后面没有增量备份,不需要指定--apply-log-only，回滚未提交事务
    xtrabackup --prepare --target-dir=$fullBackupPath/$fullBackupDate 2>> ${logfile}
  #二、天数差不为0
  else
    #2.1 预恢复备份日期等于全量备份日期
    if [ $prepareRevoveryDate == $fullBackupDate ];then
      #预恢复最新全量备份,后面还有增量备份,需指定--apply-log-only,防止回滚未提交事务
      xtrabackup --prepare --apply-log-only --target-dir=$fullBackupPath/$fullBackupDate 2>> ${logfile}
    #2.2 预恢复备份日期不等于全量备份日期
    else
      #解压预恢复增量备份
      for j in $(find $incrBackupPath/$prepareRevoveryDate -name "*.qp"); do qpress -d $j $(dirname $j) && rm -rf $j; done;
      #2.2.1 最新增量备份
      if [ i == $diffDays ];then
        #预恢复最新增量备份,不需要指定--apply-log-only，回滚未提交事务
        xtrabackup --prepare --target-dir=$fullBackupPath/$fullBackupDate --incremental-dir=$incrBackupPath/$prepareRevoveryDate 2>> ${logfile}
      #2.2.2 非最新增量备份
      else
        #预恢复非最新增量备份,需指定--apply-log-only,防止回滚未提交事务
        xtrabackup --prepare --apply-log-only --target-dir=$fullBackupPath/$fullBackupDate --incremental-dir=$incrBackupPath/$prepareRevoveryDate 2>> ${logfile}
      fi
    fi
  fi
done

#xtrabackup恢复预恢复完成的全量备份数据
xtrabackup --defaults-file=$mysqlConfig --copy-back --target-dir=$fullBackupPath/$fullBackupDate 2>> ${logfile}

#退出程序
exit 0

