#!/bin/bash
BACKUP="/bak/mysql/wl"

echo -e "$(cd $BACKUP && ls *.tar.gz)\n"

while true

do

if read -t 10 -p "请选择需要还原备份的数据包:" i
then
        echo -e "\c"
else
        echo -e "\n抱歉,你输入超时了!即将推出程序......"
  elif
	find $i -wholename $BACKUP; 
  then
	echo -e "\033[30m 数据导入中,请稍后...... \033[5m"
        break
  else
	echo "您选择的数据包有误,请重新选择"
	continue

fi
done
	


cd $BACKUP && tar -zvxf "$BACKUP/$i"
d=$(echo ${i%%.*})

cd $BACKUP/$d && gunzip -f "$BACKUP/$d/$d.sql.gz"

echo "source $BACKUP/$d/$d.sql" | mysql -u root -p123456 
echo "备份数据导入成功!"

