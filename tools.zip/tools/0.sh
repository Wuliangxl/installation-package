#!/bin/bash

#read -p "输入网站名:" website
#echo "你输入的网站名是 $website" 
#exit 0


TIME=$(date +%Y%m%d%H%M%S)
DATETIME=${TIME:0:4}"-"${TIME:4:2}"-"${TIME:6:2}"-"${TIME:8:2}":"${TIME:10:2}":"${TIME:12:2}
echo ${DATETIME}>>/dev/null 2>&1

echo ${DATETIME}





