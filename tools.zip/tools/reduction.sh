#!/bin/bash
#备份还原脚本


BACKUP="/bak/mysql/wl"
#cd $BACKUP
#ls $BACKUP *.tar.gz

echo -e "$(cd $BACKUP && ls *.tar.gz)\n"

echo -e "请选择需要还原备份的数据包:\c" 
read i
	
if find $BACKUP -wholename $i ;
then
	echo "数据导入中,请稍后......"
else
	echo "您选择的数据包有误,请重新选择"
fi


cd $BACKUP && tar -zvxf "$BACKUP/$i"

d=$(echo ${i%%.*})

cd $BACKUP/$d && gunzip -f "$BACKUP/$d/$d.sql.gz"

echo "source $BACKUP/$d/$d.sql" | mysql -u root -p123456 ww
echo "备份数据导入成功!"

echo "$(cat $BACKUP/$d/$d.sql)" | mail -s "数据备份" 2151870850@qq.com
