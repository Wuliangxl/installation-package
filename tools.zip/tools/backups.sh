#!/bin/bash
#备份目录
BACKUP="/bak/mysql/wl"

#当前时间
#TIME=$(date +%Y%m%d%H%M%S)
DATETIME=$(date +%Y-%m-%d-%H%M%S)
#DATETIME=${TIME:0:4}"-"${TIME:4:2}"-"${TIME:6:2}"_"${TIME:8:2}":"${TIME:10:2}":"${TIME:12:2}
echo $DATETIME >> /dev/null 2>&1

#数据库地址
HOST=localhost

#数据库用户名
DB_USER="root"

#数据库密码
DB_PW="123456"

#备份数据库的库名
DATABASE="wl"

#备份数据库中的表名
TABLES="user user2"
#mysql bin目录
BIN_DIR="/usr/local/mysql/bin"

#创建备份目录，如果不存在,则创建
[ ! -d "${BACKUP}/$DATETIME" ] && mkdir -p "${BACKUP}/$DATETIME"

#备份数据库
$BIN_DIR/mysqldump  -u${DB_USER} -p${DB_PW} -h$HOST -q -R --databases ${DATABASE} | gzip > ${BACKUP}/${DATETIME}/$DATETIME.sql.gz
#$BIN_DIR/mysqldump --opt --single-transaction  -u$DB_USERE -p$DB_PASS -h$DB_HOST $DB_NAME | gzip > $BCK_DIR/$DATE/db_$DB_NAME.sql.gz

#将文件处理成tar.gz
cd ${BACKUP}
tar -zcvf $DATETIME.tar.gz ${DATETIME}

#删除对应的备份目录
rm -rf ${BACKUP}/${DATETIME}

#定义删除N天/分前的备份文件
DAY=5
MIN=1
#删除10前的备份文件
find ${BACKUP} -atime +$DAY -name "*.tar.gz" -exec rm -rf {} \;
echo "备份数据库${DATABASE}成功!"


echo "$(ifconfig ens33| grep 'inet'| grep -v '127.0.0.1' | cut -d: -f2 | awk '{ print $2}')$(cd ${BACKUP}| tar -zxf $DATETIME.tar.gz)$(cd ${BACKUP}/${DATETIME})$(gunzip -f $DATETIME/$DATETIME.sql.gz)$(tail -n 100 ${BACKUP}/$DATETIME/$DATETIME.sql)" | mail -s "备份数据库" 2151870850@qq.com

rm -rf "$BACKUP/$DATETIME/"



