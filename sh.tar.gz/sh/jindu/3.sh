#!/bin/bash
#code=$( echo $(curl -I -m 10 -o /dev/null -s -w %{http_code} https://wttr.in/Nan+Chang))

#echo $code



 

function bar()

{

    i=0

    bar=""

    lable=('|' '\\' '-' '/')

    while [ $i -le 100 ]
    do


        let index=i%4

        let color=30+i%8   #字体有8种状态30~37

        echo -en "\e[1;"$color"m"  #sleep一次，字体换一次颜色 

        printf "[%-100s][%d%%][%c]\r" "$bar" "$i" "${lable[$index]}"

        bar+='#'

        sleep 0.1

        let i++

    done

    echo "" #效果相当于一个换行

    echo -e "\e[0m" #回复到原来颜色

}

 

function main()

{

    bar

}

 

main


