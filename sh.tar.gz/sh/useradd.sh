#!/bin/bash
 
# 编写脚本:提示用户输入用户名和密码,脚本自动创建相应的账户及配置密码。如果用户
# 不输入账户名,则提示必须输入账户名并退出脚本;如果用户不输入密码,则统一使用默
# 认的 123456 作为默认密码。

stty erase '^H' 	#避免删除时出现乱码 
read -p "请输入用户名: " user
#使用‐z 可以判断一个变量是否为空,如果为空,提示用户必须输入账户名,并退出脚本,退出码为 2
#没有输入用户名脚本退出后,使用$?查看的返回码为 2
if [ -z $user ];then
   	echo "您不需输入账户名"
 	exit 2
fi
#使用 stty ‐echo 关闭 shell 的回显功能
#使用 stty  echo 打开 shell 的回显功能
if grep -q "$user" /etc/passwd;then
	echo "输入的用户${user}已存在!"
while true; do
	read -p "是否继续操作[Y/N]:" a 
    case $a in [nN][oO]|[nN])	
	echo -e "登出成功!"
	exit;;
	 [yY][eE][sS]|[yY]) echo "该操作将重新创建用户:$user"
	      userdel -r $user 
	 break;;
	* ) echo "输入不合法!";;
    esac
done
fi

stty -echo
read -p "请输入密码: " pass
stty echo
echo -e ""
if [ -z $pass ];then
	useradd "$user"
	echo "123456" |passwd --stdin "$user" >> /dev/null
	echo -e "\033[31m由于您未输入密码,默认使用初始密码! \033[0m"
	exit 3
else
	pass=${pass}
	useradd "$user"
	echo "$pass"|passwd --stdin $user >>/dev/null
	echo -e "用户$user创建成功!"
	echo "$user密码为:$pass"
fi









