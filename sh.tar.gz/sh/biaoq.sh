#!/bin/bash
 
function rand(){
  min=$1
  max=$(($2-$min+1))
  num=$(date +%s%N)
  echo $(($num%$max+$min))
 return $?
}
 
rnd=$(rand 1 5) 
#echo $rnd

if [ $rnd -eq 1 ];then 
	echo " $(cat /root/sh/biaoqing/fo)"
elif [ $rnd -eq 2 ];then
	echo "$(cat /root/sh/biaoqing/maliya)"
elif [ $rnd -eq 3 ];then
	echo "$(cat /root/sh/biaoqing/chuan)"
elif [ $rnd -eq 4 ];then
        echo "$(cat /root/sh/biaoqing/zhongzhi)"
elif [ $rnd -eq 5 ];then
	sl
else 
	echo $rnd

fi
exit 0

