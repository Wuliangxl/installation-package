#!/bin/bash
 
# 根据计算机当前时间,返回问候语,可以将该脚本设置为开机启动 
 
# 00‐12 点为早晨,12‐18 点为下午,18‐24 点为晚上
# 使用 date 命令获取时间后,if 判断时间的区间,确定问候语内容
echo -e "\033[34m#==============>> 连接成功 <<==============#\033[0m"
sh /root/sh/biaoq.sh
tm=$(date +%H)
if [ $tm -le 12 ];then
	msg="Good Morning $USER"
elif [ $tm -gt 12 -a $tm -le 18 ];then
  	msg="Good Afternoon $USER"
else
  	msg="Good Night $USER"
fi

#a ="$(cat /etc/centos-release)"
echo ""
echo "当前系统版本为: $(cat /etc/centos-release)"
echo -e "当前登录用户是:\c"&& echo -e "\033[31m $USER\033[0m"
echo "当前登录时间是: $(date +"%Y‐%m‐%d %H:%M:%S")"
echo -e "正在获取当前天气情况加载中"
sh /root/sh/jindu/2s.sh
echo -e "当前天气状况为: $(curl -s http://wttr.in/Nan+Chang)"
#echo -e "\E[34;5m      $msg\E[0m"

echo ""
echo ""
echo -e "\033[34;5m             $msg\033[0m"
echo ""
echo ""
#echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
#echo "#---------------------------------------------------#"
#echo "#------------>> $(echo -e "\033[34;5m$msg\033[0m") <<--------------#"
#echo "#---------------------------------------------------#"
#echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"

